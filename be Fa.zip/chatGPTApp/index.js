import * as dotenv from 'dotenv'
import cors from 'cors';
import path from 'path';
import  express  from 'express'
import bodyParser from 'body-parser'
import { chatGPT } from './clients/CGPT.js'
import { buildMainQuestion } from './utils/functions.js'
import { fileURLToPath } from 'url';
dotenv.config()

const app = express()
const port = 3100
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Enable CORS for all routes
app.use(cors());
app.use(bodyParser.json())
// Serve the React app's build files as static assets
app.use(express.static(path.join(__dirname, 'chatty/build')));

app.post('/question', async(req, res) => {
  try {
    const {Altezza, Peso, Eta, Sesso} = req.body
    const question = buildMainQuestion({Altezza, Peso, Eta, Sesso})
    console.log(question,"QUESTION");
    const answer = question?await chatGPT(question):"C'è un problema con la creazione della domanda"
    res.status(201).send({
      res:answer
    })
  } catch (error) {
    res.status(500).send("Internal Server Error")
    console.log(error);
  }
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})
