import { ChatGPTAPI } from 'chatgpt'
export async function chatGPT(question) {
    const api = new ChatGPTAPI({
      apiKey: process.env.OPENAI_API_KEY
    })
    const res = await api.sendMessage(question)
    return res?res.text:null
  }