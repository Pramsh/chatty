export const buildMainQuestion = ({Altezza,Peso,Eta,Sesso}) => {
    return Altezza&&Peso&&Eta&&Sesso?`What would you suggest me if you'd kow that I'm a ${Eta} ${Sesso}, wich weight is ${Peso}Kg and heigth ${Altezza}?`:""
}

export const heightCheck = (height) => {
    return height > "0" ? height : new Error("Not a valid height")  
}